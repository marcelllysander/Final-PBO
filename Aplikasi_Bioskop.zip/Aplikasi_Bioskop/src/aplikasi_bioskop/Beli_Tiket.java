/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package aplikasi_bioskop;

import java.awt.*;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.IOException;
import java.util.logging.Logger;
import java.util.logging.Level;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import java.sql.SQLException;

/**
 *
 * @author Asus
 */
class Beli_Tiket extends javax.swing.JFrame {
    int xx, xy;
    Encapsulation e = new Encapsulation();
    
    
    /**
     * Creates new form Beli Tiket;
     */
    public Beli_Tiket() {
        initComponents();
        this.setExtendedState(MAXIMIZED_BOTH);
        init();
    }
    
    public void init(){
        output();
        scaleImage();
        harga_teks();
        tanggal_film();
        lokasi_film();
        jam();
        color();
    }
    
    public void output(){
        Judul.setText(e.getJudul());
    }
    
    public void color(){
        jam1.setBackground(Color.white);
        jam2.setBackground(Color.white);
        jam3.setBackground(Color.white);
        jam4.setBackground(Color.white);
        jam5.setBackground(Color.white);
        jam_vip1.setBackground(Color.white);
        jam_vip2.setBackground(Color.white);
        jam_vip3.setBackground(Color.white);
    }
    
    private void scaleImage(){
        ImageIcon icon = new ImageIcon(e.getGambar());
        //Scaling image to fit in gambar_1
        Image img = icon.getImage();
        Image imgScale = img.getScaledInstance(bg.getWidth(), bg.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(imgScale);
        bg.setText("");
        bg.setIcon(scaledIcon);
    }
    
    public void harga_teks(){
        int h;
        String harga, harga_vip;
        
        if (Hari.getSelectedItem().equals("Pilih Hari")){
            txt_lokasi.setText("-");
            txt_lokasi_vip.setText("-");
            txt_harga.setText("Rp 0");
            txt_harga_vip.setText("Rp 0");
            txt_tanggal.setText("");
            txt_tanggal_vip.setText("");
            
            h = 0;
            harga = String.valueOf(h);
            e.setHarga(harga);
        }  else if (Hari.getSelectedItem().equals("Senin") || Hari.getSelectedItem().equals("Selasa") || Hari.getSelectedItem().equals("Rabu") || Hari.getSelectedItem().equals("Kamis")){
            txt_harga.setText("Rp 35000");
            h = 35000;
            harga = String.valueOf(h);
            e.setHarga(harga);
            
            txt_harga_vip.setText("Rp 50000");
            h = 50000;
            harga_vip = String.valueOf(h);
            e.setHargaVip(harga_vip);
        } else if (Hari.getSelectedItem().equals("Jumat")){
            txt_lokasi.setText("Panakkukang");
            txt_lokasi_vip.setText("Panakkukang VIP");
            txt_harga.setText("Rp 40000");
            h = 40000;
            harga = String.valueOf(h);
            e.setHarga(harga);
            
            txt_harga_vip.setText("Rp 60000");
            h = 60000;
            harga_vip = String.valueOf(h);
            e.setHargaVip(harga_vip);
        } else if (Hari.getSelectedItem().equals("Sabtu") || Hari.getSelectedItem().equals("Minggu")){
            txt_harga.setText("Rp 50000");
            h = 50000;
            harga = String.valueOf(h);
            e.setHarga(harga);
            
            txt_harga_vip.setText("Rp 70000");
            h = 70000;
            harga_vip = String.valueOf(h);
            e.setHargaVip(harga_vip);
        }
        
        String teks_harga = txt_harga.getText();
        String teks_harga_vip = txt_harga_vip.getText();
        
        e.setTeksHarga(teks_harga);
        e.setTeksHargaVIP(teks_harga_vip);
    }
    
    
    public void tanggal_film(){
        if (Hari.getSelectedItem().equals("Senin")){
            txt_tanggal.setText("29-01-24");
            txt_tanggal_vip.setText("29-01-24");
        } else if (Hari.getSelectedItem().equals("Selasa")){
            txt_tanggal.setText("30-01-24");
            txt_tanggal_vip.setText("30-01-24");
        } else if (Hari.getSelectedItem().equals("Rabu")){
            txt_tanggal.setText("31-01-24");
            txt_tanggal_vip.setText("31-01-24");
        } else if (Hari.getSelectedItem().equals("Kamis")){
            txt_tanggal.setText("01-02-24");
            txt_tanggal_vip.setText("01-02-24");
        } else if (Hari.getSelectedItem().equals("Jumat")){
            txt_tanggal.setText("02-02-24");
            txt_tanggal_vip.setText("02-02-24");
        } else if (Hari.getSelectedItem().equals("Sabtu")){
            txt_tanggal.setText("03-02-24");
            txt_tanggal_vip.setText("03-02-24");
        } else if (Hari.getSelectedItem().equals("Minggu")){
            txt_tanggal.setText("04-02-24");
            txt_tanggal_vip.setText("04-02-24");
        }
        String tanggal = txt_tanggal.getText();
        
        e.setTanggal(tanggal);
    }
    
    public void lokasi_film(){
        if (Lokasi.getSelectedItem().equals("Pilih Bioskop")){
            txt_lokasi.setText("-");
            txt_lokasi_vip.setText("-");
        } else if (Lokasi.getSelectedItem().equals("Mall Trans Studio")){
            txt_lokasi.setText("Mall Trans Studio");
            txt_lokasi_vip.setText("Mall Trans Studio VIP");
        } else if (Lokasi.getSelectedItem().equals("Mall Panakkukang")){
            txt_lokasi.setText("Mall Panakkukang");
            txt_lokasi_vip.setText("Mall Panakkukang VIP");
        } else if (Lokasi.getSelectedItem().equals("Mall Ratu Indah")){
            txt_lokasi.setText("Mall Ratu Indah");
            txt_lokasi_vip.setText("Mall Ratu Indah VIP");
        } else if (Lokasi.getSelectedItem().equals("Mall Nipah")){
            txt_lokasi.setText("Mall Nipah");
            txt_lokasi_vip.setText("Mall Nipah VIP");
        } else if (Lokasi.getSelectedItem().equals("Mall M'Tos")){
            txt_lokasi.setText("Mall M'Tos");
            txt_lokasi_vip.setText("Mall M'Tos VIP");
        }
        String lokasi = txt_lokasi.getText();
        String lokasi_vip = txt_lokasi_vip.getText();
        
        e.setLokasi(lokasi);
        e.setLokasiVIP(lokasi_vip);
    }
    
    public void jam(){
        if (Lokasi.getSelectedItem().equals("Pilih Bioskop")){
            jam1.setText("-");
            jam2.setText("-");
            jam3.setText("-");
            jam4.setText("-");
            jam5.setText("-");
            jam_vip1.setText("-");
            jam_vip2.setText("-");
            jam_vip3.setText("-");
        } else if (Lokasi.getSelectedItem().equals("Mall Trans Studio")){
            jam1.setText("12.05");
            jam2.setText("14.20");
            jam3.setText("16.40");
            jam4.setText("19.00");
            jam5.setText("21.20");
            jam_vip1.setText("14.35");
            jam_vip2.setText("18.40");
            jam_vip3.setText("20.50");
        } else if (Lokasi.getSelectedItem().equals("Mall Panakkukang")){
            jam1.setText("12.15");
            jam2.setText("14.35");
            jam3.setText("16.00");
            jam4.setText("19.30");
            jam5.setText("21.25");
            jam_vip1.setText("13.55");
            jam_vip2.setText("16.40");
            jam_vip3.setText("20.45");
        } else if (Lokasi.getSelectedItem().equals("Mall Ratu Indah")){
            jam1.setText("12.05");
            jam2.setText("14.20");
            jam3.setText("16.40");
            jam4.setText("19.00");
            jam5.setText("21.20");
            jam_vip1.setText("15.15");
            jam_vip2.setText("19.40");
            jam_vip3.setText("21.00");
        } else if (Lokasi.getSelectedItem().equals("Mall Nipah")){
            jam1.setText("12.00");
            jam2.setText("14.10");
            jam3.setText("16.25");
            jam4.setText("18.55");
            jam5.setText("21.10");
            jam_vip1.setText("13.05");
            jam_vip2.setText("16.55");
            jam_vip3.setText("19.45");
        } else if (Lokasi.getSelectedItem().equals("Mall M'Tos")){
            jam1.setText("12.10");
            jam2.setText("14.25");
            jam3.setText("16.35");
            jam4.setText("19.15");
            jam5.setText("21.10");
            jam_vip1.setText("14.00");
            jam_vip2.setText("16.30");
            jam_vip3.setText("20.50");
        }
    }
    
    private Color rgb(String _192_193) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    class jPanelGradient extends JPanel { // membuat gradient pada navbar
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            int width = getWidth();
            int height = getHeight();
            
            Color color1 = new Color(250,79,22);
            Color color2 = new Color(189,50,4);
            
            GradientPaint gp = new GradientPaint(0,0,color1,180,height, color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, width, height);
        }
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        panel1 = new javax.swing.JPanel();
        txt_lokasi = new javax.swing.JLabel();
        txt_tanggal = new javax.swing.JLabel();
        txt_harga = new javax.swing.JLabel();
        jam1 = new javax.swing.JButton();
        jam2 = new javax.swing.JButton();
        jam3 = new javax.swing.JButton();
        jam4 = new javax.swing.JButton();
        jam5 = new javax.swing.JButton();
        panel2 = new javax.swing.JPanel();
        txt_lokasi_vip = new javax.swing.JLabel();
        txt_tanggal_vip = new javax.swing.JLabel();
        txt_harga_vip = new javax.swing.JLabel();
        jam_vip1 = new javax.swing.JButton();
        jam_vip2 = new javax.swing.JButton();
        jam_vip3 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        Lokasi = new javax.swing.JComboBox<>();
        Hari = new javax.swing.JComboBox<>();
        Lokasi_Mtos1 = new javax.swing.JLabel();
        Lokasi_Mtos2 = new javax.swing.JLabel();
        Pn_Navbar2 = new jPanelGradient();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        bg = new javax.swing.JLabel();
        Judul = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(1250, 1500));

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane1.setPreferredSize(new java.awt.Dimension(1250, 1500));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(1249, 1500));

        txt_lokasi.setText("Lokasi Bioskop");

        txt_tanggal.setText("Tanggal Film");

        txt_harga.setText("Rp 30.000");

        jam1.setText("12:00");
        jam1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jam1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jam1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jam1MouseExited(evt);
            }
        });

        jam2.setText("14:20");
        jam2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jam2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jam2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jam2MouseExited(evt);
            }
        });

        jam3.setText("16:40");
        jam3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jam3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jam3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jam3MouseExited(evt);
            }
        });

        jam4.setText("19:00");
        jam4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jam4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jam4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jam4MouseExited(evt);
            }
        });

        jam5.setText("21:20");
        jam5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jam5MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jam5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jam5MouseExited(evt);
            }
        });

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addComponent(txt_tanggal)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txt_harga)
                        .addGap(37, 37, 37))
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txt_lokasi, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(panel1Layout.createSequentialGroup()
                                .addComponent(jam1, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(31, 31, 31)
                                .addComponent(jam2, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(31, 31, 31)
                                .addComponent(jam3, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                                .addComponent(jam4, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(32, 32, 32)
                        .addComponent(jam5, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txt_lokasi)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_tanggal)
                    .addComponent(txt_harga))
                .addGap(18, 18, 18)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jam1)
                    .addComponent(jam2)
                    .addComponent(jam3)
                    .addComponent(jam4)
                    .addComponent(jam5))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        txt_lokasi_vip.setText("Lokasi Bioskop");

        txt_tanggal_vip.setText("Tanggal Film");

        txt_harga_vip.setText("Rp 40.000");

        jam_vip1.setText("12:00");
        jam_vip1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jam_vip1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jam_vip1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jam_vip1MouseExited(evt);
            }
        });

        jam_vip2.setText("16:40");
        jam_vip2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jam_vip2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jam_vip2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jam_vip2MouseExited(evt);
            }
        });

        jam_vip3.setText("21:20");
        jam_vip3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jam_vip3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jam_vip3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jam_vip3MouseExited(evt);
            }
        });

        javax.swing.GroupLayout panel2Layout = new javax.swing.GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel2Layout.createSequentialGroup()
                        .addComponent(txt_lokasi_vip, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 772, Short.MAX_VALUE))
                    .addGroup(panel2Layout.createSequentialGroup()
                        .addComponent(jam_vip1, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(151, 151, 151)
                        .addComponent(jam_vip2, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(155, 155, 155)
                        .addComponent(jam_vip3, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panel2Layout.createSequentialGroup()
                        .addComponent(txt_tanggal_vip)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txt_harga_vip)
                        .addGap(38, 38, 38))))
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txt_lokasi_vip)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_tanggal_vip)
                    .addComponent(txt_harga_vip))
                .addGap(18, 18, 18)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jam_vip1)
                    .addComponent(jam_vip2)
                    .addComponent(jam_vip3))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        Lokasi.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Bioskop", "Mall Trans Studio", "Mall Panakkukang", "Mall Ratu Indah", "Mall Nipah", "Mall M'Tos" }));
        Lokasi.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Lokasi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LokasiActionPerformed(evt);
            }
        });

        Hari.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Hari", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu" }));
        Hari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HariActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addComponent(Lokasi, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(Hari, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Lokasi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Hari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24))
        );

        Lokasi_Mtos1.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        Lokasi_Mtos1.setText("REGULAR");

        Lokasi_Mtos2.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        Lokasi_Mtos2.setText("VIP");

        Pn_Navbar2.setBackground(new java.awt.Color(204, 0, 0));
        Pn_Navbar2.setForeground(new java.awt.Color(255, 255, 255));
        Pn_Navbar2.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                Pn_Navbar2MouseDragged(evt);
            }
        });
        Pn_Navbar2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                Pn_Navbar2MousePressed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("ɱαρℓε");
        jLabel10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });

        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/aplikasi_bioskop/img/Account.png"))); // NOI18N
        jLabel11.setText("Login");
        jLabel11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
        });

        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/aplikasi_bioskop/img/French Fries.png"))); // NOI18N
        jLabel12.setText("Food");
        jLabel12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel12MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout Pn_Navbar2Layout = new javax.swing.GroupLayout(Pn_Navbar2);
        Pn_Navbar2.setLayout(Pn_Navbar2Layout);
        Pn_Navbar2Layout.setHorizontalGroup(
            Pn_Navbar2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pn_Navbar2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel11)
                .addGap(80, 80, 80))
        );
        Pn_Navbar2Layout.setVerticalGroup(
            Pn_Navbar2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pn_Navbar2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel10)
                .addContainerGap(21, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Pn_Navbar2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Pn_Navbar2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12))
                .addContainerGap())
        );

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/aplikasi_bioskop/img/Close_1.png"))); // NOI18N
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/aplikasi_bioskop/img/max.png"))); // NOI18N
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/aplikasi_bioskop/img/min.png"))); // NOI18N
        jLabel13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel13MouseClicked(evt);
            }
        });

        bg.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        Judul.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Judul.setText("JUDUL");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 51, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Lokasi_Mtos1)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(panel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(Lokasi_Mtos2, javax.swing.GroupLayout.Alignment.LEADING))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(bg, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(74, 74, 74)
                                .addComponent(Judul)))
                        .addGap(114, 114, 114))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7)
                        .addGap(42, 42, 42))))
            .addComponent(Pn_Navbar2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel9)
                    .addComponent(jLabel13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Pn_Navbar2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(bg, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(103, 103, 103)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(Judul))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                .addComponent(Lokasi_Mtos1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(61, 61, 61)
                .addComponent(Lokasi_Mtos2)
                .addGap(18, 18, 18)
                .addComponent(panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(1045, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1256, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jam1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam1MouseClicked
        jam();
        e.setJam(jam1.getText());
        e.setStudio("1");
        new Tiket().setVisible(true);
        dispose();
    }//GEN-LAST:event_jam1MouseClicked

    private void jam3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam3MouseClicked
        jam();
        e.setJam(jam3.getText());
        e.setStudio("3");
        new Tiket().setVisible(true);
        dispose();
    }//GEN-LAST:event_jam3MouseClicked

    private void jam4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam4MouseClicked
        jam();
        e.setJam(jam4.getText());
        e.setStudio("4");
        new Tiket().setVisible(true);
        dispose();
    }//GEN-LAST:event_jam4MouseClicked

    private void jam5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam5MouseClicked
        jam();
        e.setJam(jam5.getText());
        e.setStudio("5");
        new Tiket().setVisible(true);
        dispose();
    }//GEN-LAST:event_jam5MouseClicked

    private void jam_vip1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam_vip1MouseClicked
        jam();
        e.setJam(jam_vip1.getText());
        e.setStudio("VIP 1");
        new Tiket().setVisible(true);
        dispose();
    }//GEN-LAST:event_jam_vip1MouseClicked

    private void jam_vip2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam_vip2MouseClicked
        jam();
        e.setJam(jam_vip2.getText());
        e.setStudio("VIP 1");
        new Tiket().setVisible(true);
        dispose();
    }//GEN-LAST:event_jam_vip2MouseClicked

    private void jam_vip3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam_vip3MouseClicked
        jam();
        e.setJam(jam_vip3.getText());
        e.setStudio("VIP 1");
        new Tiket().setVisible(true);
        dispose();
    }//GEN-LAST:event_jam_vip3MouseClicked

    private void LokasiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LokasiActionPerformed
        harga_teks();
        tanggal_film();
        lokasi_film();
        jam();
    }//GEN-LAST:event_LokasiActionPerformed

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        new Home().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel10MouseClicked

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        new Login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel11MouseClicked

    private void jLabel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseClicked
        new Makanan();
        this.dispose();
    }//GEN-LAST:event_jLabel12MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        System.exit(0); // close program
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        if (this.getExtendedState()!= Home.MAXIMIZED_BOTH) {
            this.setExtendedState(Home.MAXIMIZED_BOTH);   // Maximize
        } else {
            this.setExtendedState(Home.NORMAL); // ukuran normal
        }
    }//GEN-LAST:event_jLabel9MouseClicked

    private void jLabel13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel13MouseClicked
        this.setExtendedState(Home.ICONIFIED); //Minimize
    }//GEN-LAST:event_jLabel13MouseClicked

    private void HariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HariActionPerformed
        harga_teks();
        tanggal_film();
    }//GEN-LAST:event_HariActionPerformed

    private void Pn_Navbar2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pn_Navbar2MousePressed
        xx = evt.getX();
        xy = evt.getY();
    }//GEN-LAST:event_Pn_Navbar2MousePressed

    private void Pn_Navbar2MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pn_Navbar2MouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xx, y - xy);
    }//GEN-LAST:event_Pn_Navbar2MouseDragged

    private void jam1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam1MouseEntered
        jam1.setBackground(Color.cyan);
    }//GEN-LAST:event_jam1MouseEntered

    private void jam1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam1MouseExited
        jam1.setBackground(Color.white);
    }//GEN-LAST:event_jam1MouseExited

    private void jam2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam2MouseEntered
        jam2.setBackground(Color.cyan);
    }//GEN-LAST:event_jam2MouseEntered

    private void jam2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam2MouseExited
        jam2.setBackground(Color.white);
    }//GEN-LAST:event_jam2MouseExited

    private void jam3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam3MouseEntered
        jam3.setBackground(Color.cyan);
    }//GEN-LAST:event_jam3MouseEntered

    private void jam3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam3MouseExited
        jam3.setBackground(Color.white);
    }//GEN-LAST:event_jam3MouseExited

    private void jam4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam4MouseEntered
        jam4.setBackground(Color.cyan);
    }//GEN-LAST:event_jam4MouseEntered

    private void jam4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam4MouseExited
        jam4.setBackground(Color.white);
    }//GEN-LAST:event_jam4MouseExited

    private void jam5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam5MouseEntered
        jam5.setBackground(Color.cyan);
    }//GEN-LAST:event_jam5MouseEntered

    private void jam5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam5MouseExited
        jam5.setBackground(Color.white);
    }//GEN-LAST:event_jam5MouseExited

    private void jam_vip1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam_vip1MouseEntered
        jam_vip1.setBackground(Color.ORANGE);
    }//GEN-LAST:event_jam_vip1MouseEntered

    private void jam_vip1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam_vip1MouseExited
        jam_vip1.setBackground(Color.white);
    }//GEN-LAST:event_jam_vip1MouseExited

    private void jam_vip2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam_vip2MouseEntered
        jam_vip2.setBackground(Color.ORANGE);
    }//GEN-LAST:event_jam_vip2MouseEntered

    private void jam_vip2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam_vip2MouseExited
        jam_vip2.setBackground(Color.white);
    }//GEN-LAST:event_jam_vip2MouseExited

    private void jam_vip3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam_vip3MouseEntered
        jam_vip3.setBackground(Color.ORANGE);
    }//GEN-LAST:event_jam_vip3MouseEntered

    private void jam_vip3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam_vip3MouseExited
        jam_vip3.setBackground(Color.white);
    }//GEN-LAST:event_jam_vip3MouseExited

    private void jam2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jam2MouseClicked
        jam();
        e.setJam(jam2.getText());
        e.setStudio("2");
        new Tiket().setVisible(true);
        dispose();
    }//GEN-LAST:event_jam2MouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> Hari;
    private javax.swing.JLabel Judul;
    private javax.swing.JComboBox<String> Lokasi;
    private javax.swing.JLabel Lokasi_Mtos1;
    private javax.swing.JLabel Lokasi_Mtos2;
    private javax.swing.JPanel Pn_Navbar2;
    private javax.swing.JLabel bg;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton jam1;
    private javax.swing.JButton jam2;
    private javax.swing.JButton jam3;
    private javax.swing.JButton jam4;
    private javax.swing.JButton jam5;
    private javax.swing.JButton jam_vip1;
    private javax.swing.JButton jam_vip2;
    private javax.swing.JButton jam_vip3;
    private javax.swing.JPanel panel1;
    private javax.swing.JPanel panel2;
    private javax.swing.JLabel txt_harga;
    private javax.swing.JLabel txt_harga_vip;
    private javax.swing.JLabel txt_lokasi;
    private javax.swing.JLabel txt_lokasi_vip;
    private javax.swing.JLabel txt_tanggal;
    private javax.swing.JLabel txt_tanggal_vip;
    // End of variables declaration//GEN-END:variables
}
