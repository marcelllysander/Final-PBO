/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package aplikasi_bioskop;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;

/**
 *
 * @author Asus
 */
public class Makanan extends javax.swing.JFrame {

    private double pajak = 0.0;
    private int total = 0;
    private int x = 0;
    
    public Makanan() {
        initComponents();
        this.setExtendedState(MAXIMIZED_BOTH);
        init();
        setVisible(true);
        
    }
    
    public void init(){
        scaleImage();
        date();
        times();
    }
    
    public void reset(){
        pajak = 0.0;
        total = 0;
        x = 0;
        spn_qty1.setValue(0);
        spn_qty2.setValue(0);
        spn_qty5.setValue(0);
        spn_qty6.setValue(0);
        spn_qty3.setValue(0);
        spn_qty7.setValue(0);
        spn_qty4.setValue(0);
        spn_qty8.setValue(0);
        spn_qty9.setValue(0);
        spn_qty10.setValue(0);
        spn_qty11.setValue(0);
        spn_qty12.setValue(0);
        jCheckBox1.setSelected(false);
        jCheckBox2.setSelected(false);
        jCheckBox5.setSelected(false);
        jCheckBox6.setSelected(false);
        jCheckBox3.setSelected(false);
        jCheckBox7.setSelected(false);
        jCheckBox4.setSelected(false);
        jCheckBox8.setSelected(false);
        jCheckBox9.setSelected(false);
        jCheckBox10.setSelected(false);
        jCheckBox11.setSelected(false);
        jCheckBox12.setSelected(false);
        Pajak.setText("0");
        Sub_Total.setText("0");
        Ak_Pajak.setText("0");
        jTextArea1.setText("");
        Ak_Pajak.setEnabled(true);
    }
    
    public class jPanelGradient extends JPanel { // membuat gradient pada navbar
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            int width = getWidth();
            int height = getHeight();
            
            Color color1 = new Color(250,79,22);
            Color color2 = new Color(189,50,4);
            
            GradientPaint gp = new GradientPaint(0,0,color1,180,height,color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, width, height);
        }
    }
    
    public void scaleImage(){
        ImageIcon icon1 = new ImageIcon("C:\\Users\\Asus\\Pictures\\Apk Bioskop\\makanan_1.jpeg");
        ImageIcon icon2 = new ImageIcon("C:\\Users\\Asus\\Pictures\\Apk Bioskop\\makanan_2.jpeg");
        ImageIcon icon3 = new ImageIcon("C:\\Users\\Asus\\Pictures\\Apk Bioskop\\makanan_3.jpeg");
        ImageIcon icon4 = new ImageIcon("C:\\Users\\Asus\\Pictures\\Apk Bioskop\\makanan_4.jpeg");
        ImageIcon icon5 = new ImageIcon("C:\\Users\\Asus\\Pictures\\Apk Bioskop\\makanan_5.jpeg");
        ImageIcon icon6 = new ImageIcon("C:\\Users\\Asus\\Pictures\\Apk Bioskop\\makanan_6.jpeg");
        ImageIcon icon7 = new ImageIcon("C:\\Users\\Asus\\Pictures\\Apk Bioskop\\makanan_7.jpeg");
        ImageIcon icon8 = new ImageIcon("C:\\Users\\Asus\\Pictures\\Apk Bioskop\\makanan_8.jpeg");
        ImageIcon icon9 = new ImageIcon("C:\\Users\\Asus\\Pictures\\Apk Bioskop\\makanan_9.jpeg");
        ImageIcon icon10 = new ImageIcon("C:\\Users\\Asus\\Pictures\\Apk Bioskop\\makanan_10.jpeg");
        ImageIcon icon11 = new ImageIcon("C:\\Users\\Asus\\Pictures\\Apk Bioskop\\makanan_11.jpeg");
        ImageIcon icon12 = new ImageIcon("C:\\Users\\Asus\\Pictures\\Apk Bioskop\\makanan_12.jpeg");
        
        //Scaling image to fit in gambar_1
        Image img1 = icon1.getImage();
        Image imgScale1 = img1.getScaledInstance(Makanan_1.getWidth(), Makanan_1.getHeight(), Image.SCALE_SMOOTH);
        Image img2 = icon2.getImage();
        Image imgScale2 = img2.getScaledInstance(Makanan_2.getWidth(), Makanan_2.getHeight(), Image.SCALE_SMOOTH);
        Image img3 = icon3.getImage();
        Image imgScale3 = img3.getScaledInstance(Makanan_3.getWidth(), Makanan_3.getHeight(), Image.SCALE_SMOOTH);
        Image img4 = icon4.getImage();
        Image imgScale4 = img4.getScaledInstance(Makanan_4.getWidth(), Makanan_4.getHeight(), Image.SCALE_SMOOTH);
        Image img5 = icon5.getImage();
        Image imgScale5 = img5.getScaledInstance(Makanan_5.getWidth(), Makanan_5.getHeight(), Image.SCALE_SMOOTH);
        Image img6 = icon6.getImage();
        Image imgScale6 = img6.getScaledInstance(Makanan_6.getWidth(), Makanan_6.getHeight(), Image.SCALE_SMOOTH);
        Image img7 = icon7.getImage();
        Image imgScale7 = img7.getScaledInstance(Makanan_7.getWidth(), Makanan_7.getHeight(), Image.SCALE_SMOOTH);
        Image img8 = icon8.getImage();
        Image imgScale8 = img8.getScaledInstance(Makanan_8.getWidth(), Makanan_8.getHeight(), Image.SCALE_SMOOTH);
        Image img9 = icon9.getImage();
        Image imgScale9 = img9.getScaledInstance(Makanan_9.getWidth(), Makanan_9.getHeight(), Image.SCALE_SMOOTH);
        Image img10 = icon10.getImage();
        Image imgScale10 = img10.getScaledInstance(Makanan_10.getWidth(), Makanan_10.getHeight(), Image.SCALE_SMOOTH);
        Image img11 = icon11.getImage();
        Image imgScale11 = img11.getScaledInstance(Makanan_11.getWidth(), Makanan_11.getHeight(), Image.SCALE_SMOOTH);
        Image img12 = icon12.getImage();
        Image imgScale12 = img12.getScaledInstance(Makanan_12.getWidth(), Makanan_12.getHeight(), Image.SCALE_SMOOTH);
        
        
        ImageIcon scaledIcon1 = new ImageIcon(imgScale1);
        Makanan_1.setIcon(scaledIcon1);
        ImageIcon scaledIcon2 = new ImageIcon(imgScale2);
        Makanan_2.setIcon(scaledIcon2);
        ImageIcon scaledIcon3 = new ImageIcon(imgScale3);
        Makanan_3.setIcon(scaledIcon3);
        ImageIcon scaledIcon4 = new ImageIcon(imgScale4);
        Makanan_4.setIcon(scaledIcon4);
        ImageIcon scaledIcon5 = new ImageIcon(imgScale5);
        Makanan_5.setIcon(scaledIcon5);
        ImageIcon scaledIcon6 = new ImageIcon(imgScale6);
        Makanan_6.setIcon(scaledIcon6);
        ImageIcon scaledIcon7 = new ImageIcon(imgScale7);
        Makanan_7.setIcon(scaledIcon7);
        ImageIcon scaledIcon8 = new ImageIcon(imgScale8);
        Makanan_8.setIcon(scaledIcon8);
        ImageIcon scaledIcon9 = new ImageIcon(imgScale9);
        Makanan_9.setIcon(scaledIcon9);
        ImageIcon scaledIcon10 = new ImageIcon(imgScale10);
        Makanan_10.setIcon(scaledIcon10);
        ImageIcon scaledIcon11 = new ImageIcon(imgScale11);
        Makanan_11.setIcon(scaledIcon11);
        ImageIcon scaledIcon12 = new ImageIcon(imgScale12);
        Makanan_12.setIcon(scaledIcon12);
    }
    
    public boolean qty0(int qty){
        if(qty == 0){
            JOptionPane.showMessageDialog(null, "Mohon mengisikan jumlah order");
            return false;
        }
        return true;
    }
    
    // Date - Tanggal
    public void date(){
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE, dd-MM-yyyy");
        
        String dd = sdf.format(d);
        Tanggal.setText(dd);
    }
    
    Timer t;
    SimpleDateFormat st;
    // Time - Jam / Waktu
    public void times(){
        
        
        t = new Timer(0, new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                //throw new UnsupportedOperationException("Not supported yet.");
            
                Date dt = new Date();
                st = new SimpleDateFormat("hh:mm:ss a");
                
                String tt = st.format(dt);
                Jam.setText(tt);
                
            
            }
        });
        t.start();
    }
    
    public void mapleCafe(){
        int id = 15020 + (int) (Math.random() * 80800);
        jTextArea1.setText("********** Maple Cafe ***********\n"
                +"Tanggal\t: " + Tanggal.getText() + "\nJam\t: " + Jam.getText() + "\n"
                + "ID Pembelian\t: " + id + "\n"
                +"******************************\n"
                +"Menu:\t\t" + "Harga (Rp)\n");
    }
    
    public void tampilan(){
        double ak_pajak = pajak * total;
        Pajak.setText(String.valueOf(String.format("%.2f", pajak)));
        Sub_Total.setText(String.valueOf(total));
        Ak_Pajak.setText(String.valueOf(ak_pajak));
        Total.setText(String.valueOf(ak_pajak + total));
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        Pn_Navbar = new jPanelGradient();
        jLabel10 = new javax.swing.JLabel();
        Tanggal = new javax.swing.JLabel();
        btnKwitansi = new javax.swing.JLabel();
        btnBack = new javax.swing.JLabel();
        btnReset = new javax.swing.JLabel();
        btnTotal = new javax.swing.JLabel();
        Jam = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        Menu_1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        lb_jdl1 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        spn_qty1 = new javax.swing.JSpinner();
        jCheckBox1 = new javax.swing.JCheckBox();
        Makanan_1 = new javax.swing.JLabel();
        Menu_2 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        lb_jdl2 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        spn_qty2 = new javax.swing.JSpinner();
        jCheckBox2 = new javax.swing.JCheckBox();
        Makanan_2 = new javax.swing.JLabel();
        Menu_5 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        lb_jdl5 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        spn_qty5 = new javax.swing.JSpinner();
        jCheckBox5 = new javax.swing.JCheckBox();
        Makanan_5 = new javax.swing.JLabel();
        Menu_6 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        lb_jdl6 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        spn_qty6 = new javax.swing.JSpinner();
        jCheckBox6 = new javax.swing.JCheckBox();
        Makanan_6 = new javax.swing.JLabel();
        Menu_7 = new javax.swing.JPanel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        lb_jdl7 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        spn_qty7 = new javax.swing.JSpinner();
        jCheckBox7 = new javax.swing.JCheckBox();
        Makanan_7 = new javax.swing.JLabel();
        Menu_3 = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        lb_jdl3 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        spn_qty3 = new javax.swing.JSpinner();
        jCheckBox3 = new javax.swing.JCheckBox();
        Makanan_3 = new javax.swing.JLabel();
        Menu_4 = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        lb_jdl4 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        spn_qty4 = new javax.swing.JSpinner();
        jCheckBox4 = new javax.swing.JCheckBox();
        Makanan_4 = new javax.swing.JLabel();
        Menu_8 = new javax.swing.JPanel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        lb_jdl8 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        spn_qty8 = new javax.swing.JSpinner();
        jCheckBox8 = new javax.swing.JCheckBox();
        Makanan_8 = new javax.swing.JLabel();
        Menu_9 = new javax.swing.JPanel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        lb_jdl9 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        spn_qty9 = new javax.swing.JSpinner();
        jCheckBox9 = new javax.swing.JCheckBox();
        Makanan_9 = new javax.swing.JLabel();
        Menu_10 = new javax.swing.JPanel();
        jLabel61 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        lb_jdl10 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        spn_qty10 = new javax.swing.JSpinner();
        jCheckBox10 = new javax.swing.JCheckBox();
        Makanan_10 = new javax.swing.JLabel();
        Menu_11 = new javax.swing.JPanel();
        jLabel67 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        lb_jdl11 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        spn_qty11 = new javax.swing.JSpinner();
        jCheckBox11 = new javax.swing.JCheckBox();
        Makanan_11 = new javax.swing.JLabel();
        Menu_12 = new javax.swing.JPanel();
        jLabel73 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        lb_jdl12 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        spn_qty12 = new javax.swing.JSpinner();
        jCheckBox12 = new javax.swing.JCheckBox();
        Makanan_12 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        Pajak = new javax.swing.JTextField();
        Sub_Total = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        Total = new javax.swing.JTextField();
        Ak_Pajak = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1250, 675));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jScrollPane1.setPreferredSize(new java.awt.Dimension(800, 675));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230), 2));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 675));

        jPanel3.setBackground(new java.awt.Color(149, 24, 24));

        Pn_Navbar.setBackground(new java.awt.Color(204, 51, 0));
        Pn_Navbar.setForeground(new java.awt.Color(255, 255, 255));
        Pn_Navbar.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                Pn_NavbarMouseDragged(evt);
            }
        });
        Pn_Navbar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                Pn_NavbarMousePressed(evt);
            }
        });

        jLabel10.setBackground(new java.awt.Color(204, 0, 0));
        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("ɱαρℓε CAFE");

        javax.swing.GroupLayout Pn_NavbarLayout = new javax.swing.GroupLayout(Pn_Navbar);
        Pn_Navbar.setLayout(Pn_NavbarLayout);
        Pn_NavbarLayout.setHorizontalGroup(
            Pn_NavbarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 159, Short.MAX_VALUE)
        );
        Pn_NavbarLayout.setVerticalGroup(
            Pn_NavbarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pn_NavbarLayout.createSequentialGroup()
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        Tanggal.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        Tanggal.setForeground(new java.awt.Color(255, 255, 255));
        Tanggal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Tanggal.setText("Welcome");

        btnKwitansi.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnKwitansi.setForeground(new java.awt.Color(255, 255, 255));
        btnKwitansi.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnKwitansi.setText("KWITANSI");
        btnKwitansi.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        btnKwitansi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnKwitansiMouseClicked(evt);
            }
        });

        btnBack.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnBack.setText("BACK");
        btnBack.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        btnBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBackMouseClicked(evt);
            }
        });

        btnReset.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnReset.setForeground(new java.awt.Color(255, 255, 255));
        btnReset.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnReset.setText("RESET");
        btnReset.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        btnReset.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnResetMouseClicked(evt);
            }
        });

        btnTotal.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnTotal.setForeground(new java.awt.Color(255, 255, 255));
        btnTotal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btnTotal.setText("TOTAL");
        btnTotal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        btnTotal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnTotalMouseClicked(evt);
            }
        });

        Jam.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        Jam.setForeground(new java.awt.Color(255, 255, 255));
        Jam.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Jam.setText("Welcome");

        jLabel36.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel36.setText("Welcome");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Pn_Navbar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Tanggal, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnKwitansi, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnBack, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnReset, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnTotal, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addComponent(Jam, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel36, javax.swing.GroupLayout.DEFAULT_SIZE, 147, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(Pn_Navbar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Tanggal)
                .addGap(18, 18, 18)
                .addComponent(Jam)
                .addGap(87, 87, 87)
                .addComponent(btnTotal)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnKwitansi)
                .addGap(18, 18, 18)
                .addComponent(btnReset)
                .addGap(18, 18, 18)
                .addComponent(btnBack)
                .addGap(0, 349, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGap(180, 180, 180)
                    .addComponent(jLabel36)
                    .addContainerGap(500, Short.MAX_VALUE)))
        );

        jLabel6.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel6.setText("Harga :");

        jLabel7.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel7.setText("QTY    :");

        jLabel8.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel8.setText("Beli     :");

        lb_jdl1.setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        lb_jdl1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lb_jdl1.setText("Chocolate Pudding");

        jLabel11.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel11.setText("Rp 20.000");

        spn_qty1.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));

        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        Makanan_1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout Menu_1Layout = new javax.swing.GroupLayout(Menu_1);
        Menu_1.setLayout(Menu_1Layout);
        Menu_1Layout.setHorizontalGroup(
            Menu_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Menu_1Layout.createSequentialGroup()
                .addGroup(Menu_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lb_jdl1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(Menu_1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(Menu_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Menu_1Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel11))
                            .addGroup(Menu_1Layout.createSequentialGroup()
                                .addGroup(Menu_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel8))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(Menu_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(spn_qty1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jCheckBox1)))))
                    .addComponent(Makanan_1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(32, 32, 32))
        );
        Menu_1Layout.setVerticalGroup(
            Menu_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Menu_1Layout.createSequentialGroup()
                .addComponent(Makanan_1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lb_jdl1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(spn_qty1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(jCheckBox1))
                .addContainerGap())
        );

        jLabel13.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel13.setText("Harga :");

        jLabel14.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel14.setText("QTY    :");

        jLabel15.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel15.setText("Beli     :");

        lb_jdl2.setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        lb_jdl2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lb_jdl2.setText("Toast");

        jLabel17.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel17.setText("Rp 25.000");

        spn_qty2.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));

        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Menu_2Layout = new javax.swing.GroupLayout(Menu_2);
        Menu_2.setLayout(Menu_2Layout);
        Menu_2Layout.setHorizontalGroup(
            Menu_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Menu_2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Menu_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Menu_2Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel17))
                    .addGroup(Menu_2Layout.createSequentialGroup()
                        .addGroup(Menu_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14)
                            .addComponent(jLabel15))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(Menu_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(spn_qty2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox2))))
                .addGap(6, 6, 6))
            .addComponent(lb_jdl2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Makanan_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        Menu_2Layout.setVerticalGroup(
            Menu_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Menu_2Layout.createSequentialGroup()
                .addComponent(Makanan_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lb_jdl2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(jLabel17))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(spn_qty2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox2)
                    .addComponent(jLabel15))
                .addContainerGap())
        );

        jLabel19.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel19.setText("Harga :");

        jLabel20.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel20.setText("QTY    :");

        jLabel21.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel21.setText("Beli     :");

        lb_jdl5.setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        lb_jdl5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lb_jdl5.setText("Fried Rice");

        jLabel23.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel23.setText("Rp 35.000");

        spn_qty5.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));

        jCheckBox5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Menu_5Layout = new javax.swing.GroupLayout(Menu_5);
        Menu_5.setLayout(Menu_5Layout);
        Menu_5Layout.setHorizontalGroup(
            Menu_5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Menu_5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Menu_5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Menu_5Layout.createSequentialGroup()
                        .addComponent(jLabel19)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel23))
                    .addGroup(Menu_5Layout.createSequentialGroup()
                        .addGroup(Menu_5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel20)
                            .addComponent(jLabel21))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(Menu_5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(spn_qty5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox5))))
                .addGap(6, 6, 6))
            .addComponent(lb_jdl5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(Menu_5Layout.createSequentialGroup()
                .addComponent(Makanan_5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        Menu_5Layout.setVerticalGroup(
            Menu_5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Menu_5Layout.createSequentialGroup()
                .addComponent(Makanan_5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lb_jdl5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(jLabel23))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(spn_qty5, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox5)
                    .addComponent(jLabel21))
                .addContainerGap())
        );

        jLabel25.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel25.setText("Harga :");

        jLabel26.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel26.setText("QTY    :");

        jLabel27.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel27.setText("Beli     :");

        lb_jdl6.setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        lb_jdl6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lb_jdl6.setText("Spagetti");

        jLabel29.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel29.setText("Rp 40.000");

        spn_qty6.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));

        jCheckBox6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Menu_6Layout = new javax.swing.GroupLayout(Menu_6);
        Menu_6.setLayout(Menu_6Layout);
        Menu_6Layout.setHorizontalGroup(
            Menu_6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Menu_6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Menu_6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Menu_6Layout.createSequentialGroup()
                        .addComponent(jLabel25)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel29))
                    .addGroup(Menu_6Layout.createSequentialGroup()
                        .addGroup(Menu_6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel26)
                            .addComponent(jLabel27))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(Menu_6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(spn_qty6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox6))))
                .addGap(6, 6, 6))
            .addComponent(lb_jdl6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Makanan_6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        Menu_6Layout.setVerticalGroup(
            Menu_6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Menu_6Layout.createSequentialGroup()
                .addComponent(Makanan_6, javax.swing.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lb_jdl6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(jLabel29))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(spn_qty6, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel26))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox6)
                    .addComponent(jLabel27))
                .addContainerGap())
        );

        jLabel37.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel37.setText("Harga :");

        jLabel38.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel38.setText("QTY    :");

        jLabel39.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel39.setText("Beli     :");

        lb_jdl7.setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        lb_jdl7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lb_jdl7.setText("Grilled Chicken");

        jLabel41.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel41.setText("Rp 55.000");

        spn_qty7.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));

        jCheckBox7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Menu_7Layout = new javax.swing.GroupLayout(Menu_7);
        Menu_7.setLayout(Menu_7Layout);
        Menu_7Layout.setHorizontalGroup(
            Menu_7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Menu_7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Menu_7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Menu_7Layout.createSequentialGroup()
                        .addComponent(jLabel37)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel41))
                    .addGroup(Menu_7Layout.createSequentialGroup()
                        .addGroup(Menu_7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel38)
                            .addComponent(jLabel39))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(Menu_7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(spn_qty7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox7))))
                .addGap(13, 13, 13))
            .addComponent(lb_jdl7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(Menu_7Layout.createSequentialGroup()
                .addComponent(Makanan_7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        Menu_7Layout.setVerticalGroup(
            Menu_7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Menu_7Layout.createSequentialGroup()
                .addComponent(Makanan_7, javax.swing.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lb_jdl7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel37)
                    .addComponent(jLabel41))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(spn_qty7, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel38))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox7)
                    .addComponent(jLabel39))
                .addContainerGap())
        );

        jLabel31.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel31.setText("Harga :");

        jLabel32.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel32.setText("QTY    :");

        jLabel33.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel33.setText("Beli     :");

        lb_jdl3.setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        lb_jdl3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lb_jdl3.setText("Gyoza");

        jLabel35.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel35.setText("Rp 20.000");

        spn_qty3.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));

        jCheckBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Menu_3Layout = new javax.swing.GroupLayout(Menu_3);
        Menu_3.setLayout(Menu_3Layout);
        Menu_3Layout.setHorizontalGroup(
            Menu_3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Menu_3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Menu_3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Menu_3Layout.createSequentialGroup()
                        .addComponent(jLabel31)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel35))
                    .addGroup(Menu_3Layout.createSequentialGroup()
                        .addGroup(Menu_3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel32)
                            .addComponent(jLabel33))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(Menu_3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(spn_qty3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox3))))
                .addGap(6, 6, 6))
            .addComponent(lb_jdl3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Makanan_3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        Menu_3Layout.setVerticalGroup(
            Menu_3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Menu_3Layout.createSequentialGroup()
                .addComponent(Makanan_3, javax.swing.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lb_jdl3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel31)
                    .addComponent(jLabel35))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(spn_qty3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel32))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox3)
                    .addComponent(jLabel33))
                .addContainerGap())
        );

        jLabel43.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel43.setText("Harga :");

        jLabel44.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel44.setText("QTY    :");

        jLabel45.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel45.setText("Beli     :");

        lb_jdl4.setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        lb_jdl4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lb_jdl4.setText("French Fries");

        jLabel47.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel47.setText("Rp 25.000");

        spn_qty4.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));

        jCheckBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Menu_4Layout = new javax.swing.GroupLayout(Menu_4);
        Menu_4.setLayout(Menu_4Layout);
        Menu_4Layout.setHorizontalGroup(
            Menu_4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Menu_4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Menu_4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Menu_4Layout.createSequentialGroup()
                        .addComponent(jLabel43)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel47))
                    .addGroup(Menu_4Layout.createSequentialGroup()
                        .addGroup(Menu_4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel44)
                            .addComponent(jLabel45))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(Menu_4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(spn_qty4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox4))))
                .addGap(6, 6, 6))
            .addComponent(lb_jdl4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Makanan_4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        Menu_4Layout.setVerticalGroup(
            Menu_4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Menu_4Layout.createSequentialGroup()
                .addComponent(Makanan_4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lb_jdl4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel43)
                    .addComponent(jLabel47))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(spn_qty4, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel44))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox4)
                    .addComponent(jLabel45))
                .addContainerGap())
        );

        jLabel49.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel49.setText("Harga :");

        jLabel50.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel50.setText("QTY    :");

        jLabel51.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel51.setText("Beli     :");

        lb_jdl8.setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        lb_jdl8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lb_jdl8.setText("Ramen");

        jLabel53.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel53.setText("Rp 40.000");

        spn_qty8.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));

        jCheckBox8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Menu_8Layout = new javax.swing.GroupLayout(Menu_8);
        Menu_8.setLayout(Menu_8Layout);
        Menu_8Layout.setHorizontalGroup(
            Menu_8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Menu_8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Menu_8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Menu_8Layout.createSequentialGroup()
                        .addComponent(jLabel49)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel53))
                    .addGroup(Menu_8Layout.createSequentialGroup()
                        .addGroup(Menu_8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel50)
                            .addComponent(jLabel51))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(Menu_8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(spn_qty8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox8))))
                .addGap(6, 6, 6))
            .addComponent(lb_jdl8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Makanan_8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        Menu_8Layout.setVerticalGroup(
            Menu_8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Menu_8Layout.createSequentialGroup()
                .addComponent(Makanan_8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lb_jdl8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel49)
                    .addComponent(jLabel53))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(spn_qty8, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel50))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox8)
                    .addComponent(jLabel51))
                .addContainerGap())
        );

        jLabel55.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel55.setText("Harga :");

        jLabel56.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel56.setText("QTY    :");

        jLabel57.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel57.setText("Beli     :");

        lb_jdl9.setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        lb_jdl9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lb_jdl9.setText("Hot / Ice Tea");

        jLabel59.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel59.setText("Rp 15.000");

        spn_qty9.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));

        jCheckBox9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox9ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Menu_9Layout = new javax.swing.GroupLayout(Menu_9);
        Menu_9.setLayout(Menu_9Layout);
        Menu_9Layout.setHorizontalGroup(
            Menu_9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Menu_9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Menu_9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Menu_9Layout.createSequentialGroup()
                        .addComponent(jLabel55)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel59))
                    .addGroup(Menu_9Layout.createSequentialGroup()
                        .addGroup(Menu_9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel56)
                            .addComponent(jLabel57))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(Menu_9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(spn_qty9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox9))))
                .addGap(6, 6, 6))
            .addComponent(lb_jdl9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(Menu_9Layout.createSequentialGroup()
                .addComponent(Makanan_9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        Menu_9Layout.setVerticalGroup(
            Menu_9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Menu_9Layout.createSequentialGroup()
                .addComponent(Makanan_9, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lb_jdl9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Menu_9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel55)
                    .addComponent(jLabel59))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(spn_qty9, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel56))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox9)
                    .addComponent(jLabel57))
                .addContainerGap())
        );

        jLabel61.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel61.setText("Harga :");

        jLabel62.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel62.setText("QTY    :");

        jLabel63.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel63.setText("Beli     :");

        lb_jdl10.setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        lb_jdl10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lb_jdl10.setText("Orange Juice");

        jLabel65.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel65.setText("Rp 20.000");

        spn_qty10.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));

        jCheckBox10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox10ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Menu_10Layout = new javax.swing.GroupLayout(Menu_10);
        Menu_10.setLayout(Menu_10Layout);
        Menu_10Layout.setHorizontalGroup(
            Menu_10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Menu_10Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Menu_10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Menu_10Layout.createSequentialGroup()
                        .addComponent(jLabel61)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel65))
                    .addGroup(Menu_10Layout.createSequentialGroup()
                        .addGroup(Menu_10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel62)
                            .addComponent(jLabel63))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(Menu_10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(spn_qty10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox10))))
                .addGap(6, 6, 6))
            .addComponent(lb_jdl10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Makanan_10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        Menu_10Layout.setVerticalGroup(
            Menu_10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Menu_10Layout.createSequentialGroup()
                .addComponent(Makanan_10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lb_jdl10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel61)
                    .addComponent(jLabel65))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(spn_qty10, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel62))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox10)
                    .addComponent(jLabel63))
                .addContainerGap())
        );

        jLabel67.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel67.setText("Harga :");

        jLabel68.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel68.setText("QTY    :");

        jLabel69.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel69.setText("Beli     :");

        lb_jdl11.setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        lb_jdl11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lb_jdl11.setText("Vanilla Milkshake");

        jLabel71.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel71.setText("Rp 20.000");

        spn_qty11.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));

        jCheckBox11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox11ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Menu_11Layout = new javax.swing.GroupLayout(Menu_11);
        Menu_11.setLayout(Menu_11Layout);
        Menu_11Layout.setHorizontalGroup(
            Menu_11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Menu_11Layout.createSequentialGroup()
                .addGroup(Menu_11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lb_jdl11, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Menu_11Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(Menu_11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Menu_11Layout.createSequentialGroup()
                                .addComponent(jLabel67)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel71))
                            .addGroup(Menu_11Layout.createSequentialGroup()
                                .addGroup(Menu_11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel68)
                                    .addComponent(jLabel69))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(Menu_11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(spn_qty11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jCheckBox11))))))
                .addGap(23, 23, 23))
            .addGroup(Menu_11Layout.createSequentialGroup()
                .addComponent(Makanan_11, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        Menu_11Layout.setVerticalGroup(
            Menu_11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Menu_11Layout.createSequentialGroup()
                .addComponent(Makanan_11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lb_jdl11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel67)
                    .addComponent(jLabel71))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(spn_qty11, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel68))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox11)
                    .addComponent(jLabel69))
                .addContainerGap())
        );

        jLabel73.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel73.setText("Harga :");

        jLabel74.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel74.setText("QTY    :");

        jLabel75.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel75.setText("Beli     :");

        lb_jdl12.setFont(new java.awt.Font("Verdana", 1, 10)); // NOI18N
        lb_jdl12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lb_jdl12.setText("Air Mineral");

        jLabel77.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jLabel77.setText("Rp 10.000");

        spn_qty12.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));

        jCheckBox12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox12ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Menu_12Layout = new javax.swing.GroupLayout(Menu_12);
        Menu_12.setLayout(Menu_12Layout);
        Menu_12Layout.setHorizontalGroup(
            Menu_12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Menu_12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Menu_12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Menu_12Layout.createSequentialGroup()
                        .addComponent(jLabel73)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel77))
                    .addGroup(Menu_12Layout.createSequentialGroup()
                        .addGroup(Menu_12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel74)
                            .addComponent(jLabel75))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(Menu_12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(spn_qty12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox12))))
                .addGap(6, 6, 6))
            .addComponent(lb_jdl12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Makanan_12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        Menu_12Layout.setVerticalGroup(
            Menu_12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Menu_12Layout.createSequentialGroup()
                .addComponent(Makanan_12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lb_jdl12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel73)
                    .addComponent(jLabel77))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(spn_qty12, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel74))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Menu_12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckBox12)
                    .addComponent(jLabel75))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(Menu_5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addComponent(Menu_1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(Menu_9, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(Menu_10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Menu_11, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Menu_12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(Menu_6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Menu_7, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Menu_8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(Menu_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Menu_3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Menu_4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(112, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(Menu_3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Menu_2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Menu_1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Menu_4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Menu_7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Menu_8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(Menu_6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Menu_5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Menu_11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Menu_10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Menu_12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Menu_9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(111, 111, 111))
        );

        jScrollPane1.setViewportView(jPanel1);

        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        Pajak.setEditable(false);
        Pajak.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        Pajak.setText("0");

        Sub_Total.setEditable(false);
        Sub_Total.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        Sub_Total.setText("0");

        jLabel5.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        jLabel5.setText("AK. PAJAK");

        jLabel12.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        jLabel12.setText("PAJAK");

        jLabel18.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        jLabel18.setText("SUB TOTAL");

        jLabel9.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        jLabel9.setText("TOTAL");

        Total.setEditable(false);
        Total.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        Total.setText("0");

        Ak_Pajak.setEditable(false);
        Ak_Pajak.setFont(new java.awt.Font("Verdana", 1, 15)); // NOI18N
        Ak_Pajak.setText("0");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 724, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(108, 108, 108)
                        .addComponent(Total, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel5)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Ak_Pajak, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel18)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Sub_Total, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel12)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Pajak, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(236, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 482, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addComponent(Pajak, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Sub_Total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel18))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(Ak_Pajak, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9)))))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBackMouseClicked
        new Home().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnBackMouseClicked

    private void btnResetMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnResetMouseClicked
        reset();
    }//GEN-LAST:event_btnResetMouseClicked

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        int qty = Integer.parseInt(spn_qty1.getValue().toString());
        if(qty0(qty) && jCheckBox1.isSelected()){
            x++;
            if(x == 1){
                mapleCafe();
            }
            int harga = qty*20000;
            total += harga;
            getPajak(total);
            jTextArea1.setText(jTextArea1.getText() + x + ". " + lb_jdl1.getText() + "\t" + harga + "\n");
            tampilan();
        } else {
            jCheckBox1.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
        int qty = Integer.parseInt(spn_qty2.getValue().toString());
        if(qty0(qty) && jCheckBox2.isSelected()){
            x++;
            if(x == 1){
                mapleCafe();
            }
            int harga = qty*25000;
            total += harga;
            getPajak(total);
            jTextArea1.setText(jTextArea1.getText() + x + ". " + lb_jdl2.getText() + "\t\t" + harga + "\n");
            tampilan();
        } else {
            jCheckBox2.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox2ActionPerformed

    private void jCheckBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox3ActionPerformed
        int qty = Integer.parseInt(spn_qty3.getValue().toString());
        if(qty0(qty) && jCheckBox3.isSelected()){
            x++;
            if(x == 1){
                mapleCafe();
            }
            int harga = qty*20000;
            total += harga;
            getPajak(total);
            jTextArea1.setText(jTextArea1.getText() + x + ". " + lb_jdl3.getText() + "\t\t" + harga + "\n");
            tampilan();
        } else {
            jCheckBox3.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox3ActionPerformed

    private void jCheckBox9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox9ActionPerformed
        int qty = Integer.parseInt(spn_qty9.getValue().toString());
        if(qty0(qty) && jCheckBox9.isSelected()){
            x++;
            if(x == 1){
                mapleCafe();
            }
            int harga = qty*15000;
            total += harga;
            getPajak(total);
            jTextArea1.setText(jTextArea1.getText() + x + ". " + lb_jdl9.getText() + "\t\t" + harga + "\n");
            tampilan();
        } else {
            jCheckBox9.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox9ActionPerformed

    private void jCheckBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox4ActionPerformed
        int qty = Integer.parseInt(spn_qty4.getValue().toString());
        if(qty0(qty) && jCheckBox4.isSelected()){
            x++;
            if(x == 1){
                mapleCafe();
            }
            int harga = qty*25000;
            total += harga;
            getPajak(total);
            jTextArea1.setText(jTextArea1.getText() + x + ". " + lb_jdl4.getText() + "\t\t" + harga + "\n");
            tampilan();
        } else {
            jCheckBox4.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox4ActionPerformed

    private void jCheckBox5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox5ActionPerformed
        int qty = Integer.parseInt(spn_qty5.getValue().toString());
        if(qty0(qty) && jCheckBox5.isSelected()){
            x++;
            if(x == 1){
                mapleCafe();
            }
            int harga = qty*35000;
            total += harga;
            getPajak(total);
            jTextArea1.setText(jTextArea1.getText() + x + ". " + lb_jdl5.getText() + "\t\t" + harga + "\n");
            tampilan();
        } else {
            jCheckBox5.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox5ActionPerformed

    private void jCheckBox6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox6ActionPerformed
        int qty = Integer.parseInt(spn_qty6.getValue().toString());
        if(qty0(qty) && jCheckBox6.isSelected()){
            x++;
            if(x == 1){
                mapleCafe();
            }
            int harga = qty*40000;
            total += harga;
            getPajak(total);
            jTextArea1.setText(jTextArea1.getText() + x + ". " + lb_jdl6.getText() + "\t\t" + harga + "\n");
            tampilan();
        } else {
            jCheckBox6.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox6ActionPerformed

    private void jCheckBox7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox7ActionPerformed
        int qty = Integer.parseInt(spn_qty7.getValue().toString());
        if(qty0(qty) && jCheckBox7.isSelected()){
            x++;
            if(x == 1){
                mapleCafe();
            }
            int harga = qty*55000;
            total += harga;
            getPajak(total);
            jTextArea1.setText(jTextArea1.getText() + x + ". " + lb_jdl7.getText() + "\t" + harga + "\n");
            tampilan();
        } else {
            jCheckBox7.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox7ActionPerformed

    private void jCheckBox8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox8ActionPerformed
        int qty = Integer.parseInt(spn_qty8.getValue().toString());
        if(qty0(qty) && jCheckBox8.isSelected()){
            x++;
            if(x == 1){
                mapleCafe();
            }
            int harga = qty*40000;
            total += harga;
            getPajak(total);
            jTextArea1.setText(jTextArea1.getText() + x + ". " + lb_jdl8.getText() + "\t\t" + harga + "\n");
            tampilan();
        } else {
            jCheckBox8.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox8ActionPerformed

    private void jCheckBox10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox10ActionPerformed
        int qty = Integer.parseInt(spn_qty10.getValue().toString());
        if(qty0(qty) && jCheckBox10.isSelected()){
            x++;
            if(x == 1){
                mapleCafe();
            }
            int harga = qty*20000;
            total += harga;
            getPajak(total);
            jTextArea1.setText(jTextArea1.getText() + x + ". " + lb_jdl10.getText() + "\t\t" + harga + "\n");
            tampilan();
        } else {
            jCheckBox10.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox10ActionPerformed

    private void jCheckBox11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox11ActionPerformed
        int qty = Integer.parseInt(spn_qty11.getValue().toString());
        if(qty0(qty) && jCheckBox11.isSelected()){
            x++;
            if(x == 1){
                mapleCafe();
            }
            int harga = qty*20000;
            total += harga;
            getPajak(total);
            jTextArea1.setText(jTextArea1.getText() + x + ". " + lb_jdl11.getText() + "\t" + harga + "\n");
            tampilan();
        } else {
            jCheckBox11.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox11ActionPerformed

    private void jCheckBox12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox12ActionPerformed
        int qty = Integer.parseInt(spn_qty12.getValue().toString());
        if(qty0(qty) && jCheckBox12.isSelected()){
            x++;
            if(x == 1){
                mapleCafe();
            }
            int harga = qty*10000;
            total += harga;
            getPajak(total);
            jTextArea1.setText(jTextArea1.getText() + x + ". " + lb_jdl12.getText() + "\t\t" + harga + "\n");
            tampilan();
        } else {
            jCheckBox12.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox12ActionPerformed

    private void btnTotalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnTotalMouseClicked
        if(total == 0){
            JOptionPane.showMessageDialog(null, "Kamu belum memesan apapun");
        } else {
            double ak_pajak = pajak * total;
            jTextArea1.setText(jTextArea1.getText()
                + "\n******************************\n"
                + "Pajak :\t\t" + pajak + "\n"
                + "Sub Total :\t\t" + total + "\n"
                + "Akumulasi Pajak :\t" + ak_pajak + "\n"
                + "Total :\t\t" + (ak_pajak + total) + "\n\n"
                + "********** Thank You ***********\n"
            );
            Ak_Pajak.setEnabled(false);
        }
    }//GEN-LAST:event_btnTotalMouseClicked
    
    int xx, xy;
    
    private void Pn_NavbarMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pn_NavbarMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x-xx, y-xy);
    }//GEN-LAST:event_Pn_NavbarMouseDragged

    private void Pn_NavbarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pn_NavbarMousePressed
        xx = evt.getX();
        xy = evt.getY();
    }//GEN-LAST:event_Pn_NavbarMousePressed

    private void btnKwitansiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnKwitansiMouseClicked
        if(total != 0){
            if(!btnTotal.isEnabled()){
                try {
                    jTextArea1.print();
                } catch (PrinterException ex){
                    //Logger.getLogger(Dashboard.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
            JOptionPane.showMessageDialog(null, "Memencet total terlebih dahulu");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Kamu belum membeli apapun");
        }
    }//GEN-LAST:event_btnKwitansiMouseClicked

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        for(double i = 0.0; i <= 1.0; i += 0.1){
            String s = i + "";
            float f = Float.valueOf(s);
            this.setOpacity(f);
            try {
                Thread.sleep(40);
            } catch (InterruptedException ex){
                //Logger.getLogger(Dashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_formWindowOpened
    
    public void getPajak(int p){
        if (p >= 10000 && p <= 20000){
            pajak = 0.075;
        } else if (p > 20000){
            pajak = 0.1;
        }
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Ak_Pajak;
    private javax.swing.JLabel Jam;
    private javax.swing.JLabel Makanan_1;
    private javax.swing.JLabel Makanan_10;
    private javax.swing.JLabel Makanan_11;
    private javax.swing.JLabel Makanan_12;
    private javax.swing.JLabel Makanan_2;
    private javax.swing.JLabel Makanan_3;
    private javax.swing.JLabel Makanan_4;
    private javax.swing.JLabel Makanan_5;
    private javax.swing.JLabel Makanan_6;
    private javax.swing.JLabel Makanan_7;
    private javax.swing.JLabel Makanan_8;
    private javax.swing.JLabel Makanan_9;
    private javax.swing.JPanel Menu_1;
    private javax.swing.JPanel Menu_10;
    private javax.swing.JPanel Menu_11;
    private javax.swing.JPanel Menu_12;
    private javax.swing.JPanel Menu_2;
    private javax.swing.JPanel Menu_3;
    private javax.swing.JPanel Menu_4;
    private javax.swing.JPanel Menu_5;
    private javax.swing.JPanel Menu_6;
    private javax.swing.JPanel Menu_7;
    private javax.swing.JPanel Menu_8;
    private javax.swing.JPanel Menu_9;
    private javax.swing.JTextField Pajak;
    private javax.swing.JPanel Pn_Navbar;
    private javax.swing.JTextField Sub_Total;
    private javax.swing.JLabel Tanggal;
    private javax.swing.JTextField Total;
    private javax.swing.JLabel btnBack;
    private javax.swing.JLabel btnKwitansi;
    private javax.swing.JLabel btnReset;
    private javax.swing.JLabel btnTotal;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox10;
    private javax.swing.JCheckBox jCheckBox11;
    private javax.swing.JCheckBox jCheckBox12;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBox5;
    private javax.swing.JCheckBox jCheckBox6;
    private javax.swing.JCheckBox jCheckBox7;
    private javax.swing.JCheckBox jCheckBox8;
    private javax.swing.JCheckBox jCheckBox9;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel lb_jdl1;
    private javax.swing.JLabel lb_jdl10;
    private javax.swing.JLabel lb_jdl11;
    private javax.swing.JLabel lb_jdl12;
    private javax.swing.JLabel lb_jdl2;
    private javax.swing.JLabel lb_jdl3;
    private javax.swing.JLabel lb_jdl4;
    private javax.swing.JLabel lb_jdl5;
    private javax.swing.JLabel lb_jdl6;
    private javax.swing.JLabel lb_jdl7;
    private javax.swing.JLabel lb_jdl8;
    private javax.swing.JLabel lb_jdl9;
    private javax.swing.JSpinner spn_qty1;
    private javax.swing.JSpinner spn_qty10;
    private javax.swing.JSpinner spn_qty11;
    private javax.swing.JSpinner spn_qty12;
    private javax.swing.JSpinner spn_qty2;
    private javax.swing.JSpinner spn_qty3;
    private javax.swing.JSpinner spn_qty4;
    private javax.swing.JSpinner spn_qty5;
    private javax.swing.JSpinner spn_qty6;
    private javax.swing.JSpinner spn_qty7;
    private javax.swing.JSpinner spn_qty8;
    private javax.swing.JSpinner spn_qty9;
    // End of variables declaration//GEN-END:variables
}
