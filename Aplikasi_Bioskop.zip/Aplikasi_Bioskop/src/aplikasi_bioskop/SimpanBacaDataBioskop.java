/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aplikasi_bioskop;

import java.io.*;
/**
 *
 * @author Asus
 */
public class SimpanBacaDataBioskop {
    
    
    
public void SimpanData(String judul, String bioskop, String tanggal, String harga, String jam){
        
        try{
            FileOutputStream fout = new FileOutputStream("Data Bioskop.dat", true);
            DataOutputStream out = new DataOutputStream(fout);
            out.writeUTF(judul);
            out.writeUTF(bioskop);
            out.writeUTF(tanggal);
            out.writeUTF(harga);
            out.writeUTF(jam);
            out.close();
        }catch(IOException e){
            System.out.println(e.toString());
        }
    }
    
    public String BacaData(){
        String judul, bioskop, tanggal, harga, jam;
        String temp = "", data = "";
        try{
            FileInputStream fin = new FileInputStream("Data Bioskop.dat");
            DataInputStream in = new DataInputStream(fin);
            
            while(in.available() > 0){
                judul = in.readUTF();
                bioskop = in.readUTF();
                tanggal = in.readUTF();
                harga = in.readUTF();
                jam = in.readUTF();
                temp = "Judul Film : " + judul + "\nLokasi Bioskop \t:" + bioskop + "\nTanggal Nonton \t:" + tanggal + "\nharga \t:" + harga + "\nJam \t:" + jam + "\n\n";
                data += temp;
            }
            in.close();
        }catch(IOException e){
            System.out.println(e.toString());
        }
        return(data);
    }
}
