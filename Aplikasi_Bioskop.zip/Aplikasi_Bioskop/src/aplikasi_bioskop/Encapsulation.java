/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aplikasi_bioskop;

/**
 *
 * @author Asus
 */
public class Encapsulation {
    
    StringBuilder sb = new StringBuilder();
    
    private static String e_judul;
    private static String e_sinopsis;
    private static String e_info;
    private static String e_gambar;
    private static String e_lokasi;
    private static String e_lokasi_vip;
    private static String e_tanggal;
    private static String e_harga;
    private static String e_harga_vip;
    private static String e_teks_harga;
    private static String e_teks_harga_vip;
    private static String e_jam;
    private static String e_tiket;
    private static String e_duduk;
    private static String e_studio;
    private static String e_kode;
    private static String e_url;
    
    public void setJudul(String judul){
        e_judul = judul;
    }
    
    public String getJudul(){
        return this.e_judul;
    }
    
    public void setSinopsis(String sinopsis){
        e_sinopsis = sinopsis;
    }
    
    public String getSinopsis(){
        return this.e_sinopsis;
    }
    
    public void setInfo(String info){
        e_info = info;
    }
    
    public String getInfo(){
        return this.e_info;
    }
    
    public void setGambar(String gambar){
        e_gambar = gambar;
    }
    
    public String getGambar(){
        return this.e_gambar;
    }
    
    public void setLokasi(String lokasi){
        e_lokasi = lokasi;
    }
    
    public String getLokasi(){
        return this.e_lokasi;
    }
    
    public void setLokasiVIP(String lokasi_vip){
        e_lokasi_vip = lokasi_vip;
    }
    
    public String getLokasiVIP(){
        return this.e_lokasi_vip;
    }
    
    public void setTanggal(String tanggal){
        e_tanggal = tanggal;
    }
    
    public String getTanggal(){
        return this.e_tanggal;
    }
    
    public void setHarga(String harga){
        e_harga = harga;
    }
    
    public String getHarga(){
        return this.e_harga;
    }
    
    public void setHargaVip(String harga_vip){
        e_harga_vip = harga_vip;
    }
    
    public String getHargaVip(){
        return this.e_harga_vip;
    }
    
    public void setTeksHarga(String teks_harga){
        e_teks_harga = teks_harga;
    }
    
    public String getTeksHarga(){
        return this.e_teks_harga;
    }
    
    public void setTeksHargaVIP(String teks_harga_vip){
        e_teks_harga_vip = teks_harga_vip;
    }
    
    public String getTeksHargaVIP(){
        return this.e_teks_harga_vip;
    }
    
    public void setJam(String jam){
        e_jam = jam;
    }
    
    public String getJam(){
        return this.e_jam;
    }
    
    public void setTiket(String tiket){
        e_tiket = tiket;
    }
    
    public String getTiket(){
        return this.e_tiket;
    }
    
    public void setDuduk(String duduk){
        e_duduk = duduk;
    }
    
    public String getDuduk(){
        return this.e_duduk;
    }
    
    public void setStudio(String studio){
        e_studio = studio;
    }
    
    public String getStudio(){
        return this.e_studio;
    }
    
    public void setKode(String kode){
        e_kode = kode;
    }
    
    public String getKode(){
        return this.e_kode;
    }
    
    public void setUrl(String url){
        e_url = url;
    }
    
    public String getUrl(){
        return this.e_url;
    }
    
}

